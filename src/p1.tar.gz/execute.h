#ifndef _EXECUTE_
#define _EXECUTE_

void execute(int argc, char* argv[]);

#endif
