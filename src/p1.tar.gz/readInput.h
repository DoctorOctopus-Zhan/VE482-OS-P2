#ifndef _READINPUT_
#define _READINPUT_

int readInput(void);

#endif
