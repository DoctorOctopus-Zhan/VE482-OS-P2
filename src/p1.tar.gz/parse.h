#ifndef _PARSE_
#define _PARSE_

void parse(char* line);

#endif
